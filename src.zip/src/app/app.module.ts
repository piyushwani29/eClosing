import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';
import { MyMaterialModule } from  './material.module';
import { AppComponent } from './app.component';
import { RegistrationComponentComponent } from './registration-component/registration-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdminConsoleComponentComponent } from './admin-console-component/admin-console-component.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import {MatIconModule} from '@angular/material/icon';
import { HttpClientModule }    from '@angular/common/http';
import { AdminHomeComponentComponent } from './admin-home-component/admin-home-component.component';
import {MatTableModule} from '@angular/material/table';

@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponentComponent,
    LoginComponentComponent,
    AdminConsoleComponentComponent,
    HomeComponentComponent,
    AdminHomeComponentComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MyMaterialModule,
    MatIconModule,
    MatTableModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', redirectTo: '/home', pathMatch: 'full' },
      { path: 'register', component: RegistrationComponentComponent },
      { path: 'login', component: LoginComponentComponent },
      { path: 'networkInfo', component:  AdminConsoleComponentComponent}  ,
      { path: 'home', component:  HomeComponentComponent},
      { path: 'adminhome', component:  AdminHomeComponentComponent}  
     
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
