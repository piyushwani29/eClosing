import { Component } from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
}
