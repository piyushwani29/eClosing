import { Component, OnInit , ChangeDetectorRef} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { MatGridList } from '@angular/material';

export interface DocList {
  Id: number;
  Hash: string;
  Status: string;
}

export interface List{
  List: DocList[];
}
const ELEMENT_DATA: DocList[] = [
  {Id:1,Hash:"0xfghjjjkjkkjkj",Status :"Signature validated, funds transferred"},
 {Id:2,Hash:"0xbvbvbghhghgkj",Status:"Signature validated, funds transferred"},
 {Id:3,Hash:"0xhgjkiytcbhgj",Status:"Signature validated, funds transferred"}
];
 
@Component({
  selector: 'app-admin-home-component',
  templateUrl: './admin-home-component.component.html',
  styleUrls: ['./admin-home-component.component.css']
})

export class AdminHomeComponentComponent implements OnInit {
   list: Array<DocList>=[];
  constructor(private http: HttpClient, private changeDetectorRefs : ChangeDetectorRef ) { 
  }
  
  ngOnInit() {
    //console.log(this.list);
   //this.dataSource=this.list;
  }
  displayedColumns: string[] = ['Id', 'Hash', 'Status'];
  dataSource= ELEMENT_DATA ;
  
  onFileInput(event : any): void{
   // console.log(event.target.value);
    //var gridList : List[] = this.list;
    //console.log(gridList.values);
     this.http.post('/save',event.target.value).subscribe();
    this. refresh();
    this.list=[];
  }

    refresh(){
      this.getDocList().subscribe((data => data.List.forEach(element => {
        this.list.push(element)
        }) ));
        this.dataSource=this.list;
        this.changeDetectorRefs.detectChanges();
    }
  getDocList():Observable<any>{
    return  this.http.get("/getDocList")
    .map((res:DocList[]) => res);
  }
}
