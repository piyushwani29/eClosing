import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminConsoleComponentComponent } from './admin-console-component.component';

describe('AdminConsoleComponentComponent', () => {
  let component: AdminConsoleComponentComponent;
  let fixture: ComponentFixture<AdminConsoleComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminConsoleComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminConsoleComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
