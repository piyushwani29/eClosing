import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-console-component',
  templateUrl: './admin-console-component.component.html',
  styleUrls: ['./admin-console-component.component.css']
})
export class AdminConsoleComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
