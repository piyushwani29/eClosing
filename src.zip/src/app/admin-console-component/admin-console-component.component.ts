import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-admin-console-component',
  templateUrl: './admin-console-component.component.html',
  styleUrls: ['./admin-console-component.component.css']
})
export class AdminConsoleComponentComponent implements OnInit {
  value=true;
  constructor(private http: HttpClient) { }

  ngOnInit() {
  }
  bringNetworkUp(){
    this.http.post("/bringNetworkup", this.value).subscribe(data => console.log(data));
  }
}
